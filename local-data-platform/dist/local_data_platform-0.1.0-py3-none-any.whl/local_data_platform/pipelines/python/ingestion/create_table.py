

class LakehouseTable