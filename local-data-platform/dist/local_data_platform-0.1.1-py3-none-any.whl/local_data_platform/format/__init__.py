from local_data_platform import Table


class Format(Table):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
