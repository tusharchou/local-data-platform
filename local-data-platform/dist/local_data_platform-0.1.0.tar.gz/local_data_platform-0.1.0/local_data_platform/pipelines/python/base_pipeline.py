class BasePipeline():
    source
    target
    def extract(self):
        pass

    def transform(self):
        pass
    def load(self):
        pass
